export const environment = {
  production: true,
  apiBase: 'https://your-production-api.com/api'
};
